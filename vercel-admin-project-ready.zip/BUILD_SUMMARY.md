# BUILD SUMMARY

## Entrega
Projeto preparado em HTML/CSS/JS puro para upload manual na Vercel, preservando a landing original na raiz e adicionando um painel `/admin` com autenticação simples por senha.

## Estrutura principal
- `/index.html`: landing pública adaptada da base original
- `/admin/index.html`: painel administrativo dark theme
- `/admin/admin.js`: lógica do painel, login e polling quase em tempo real
- `/api/track.js`: coleta server-side de eventos
- `/api/admin/login.js`: validação da senha do admin
- `/api/admin/summary.js`: resumo de métricas
- `/api/admin/events.js`: eventos recentes
- `/api/admin/funnel.js`: funil consolidado
- `/api/admin/realtime.js`: snapshot para polling curto e robusto
- `/lib/analytics-core.js`: normalização, agregação e funil
- `/lib/storage.js`: camada de persistência compatível com KV REST e fallback em memória
- `/lib/http.js`: helpers HTTP, CORS e proteção do admin
- `/js/tracker.js`: tracking centralizado da landing
- `/vercel.json`: rewrites, headers e runtime das funções

## Persistência
A escrita e leitura usam KV REST quando `KV_REST_API_URL` e `KV_REST_API_TOKEN` estão disponíveis.
Em desenvolvimento local, ou se KV não estiver configurado, o projeto usa fallback seguro em memória.
A produção não depende de banco local.

## Segurança do admin
O painel exige senha via formulário.
As rotas administrativas validam `x-admin-key` contra `ADMIN_PASSWORD`.
Se `ADMIN_PASSWORD` não estiver configurada, as APIs retornam aviso claro de configuração ausente.

## Tracking implementado
Eventos preparados:
- `session_start`
- `page_view`
- `scroll_25`
- `scroll_50`
- `scroll_75`
- `scroll_100`
- `cta_click`
- `checkout_click`
- `heartbeat`

Metadados preparados:
- UTM source/medium/campaign/content/term
- `fbclid`
- `userAgent`
- `language`
- `timezone`
- `screen`
- `viewport`
- device e browser inferidos no servidor
- path e referrer

## Validação local
Validação local feita com servidor Node simples (`npm run dev`) em `http://localhost:3000`.
Foram verificados:
- landing `/`
- admin `/admin`
- POST em `/api/track`
- GET autenticado em `/api/admin/summary`
- GET autenticado em `/api/admin/events`
- GET autenticado em `/api/admin/funnel`
- GET autenticado em `/api/admin/realtime`

Também foram geradas capturas locais:
- `validation-landing.png`
- `validation-admin.png`

## Variáveis esperadas
- `ADMIN_PASSWORD` obrigatória
- `KV_REST_API_URL` opcional
- `KV_REST_API_TOKEN` opcional
- `KV_REST_API_READ_ONLY_TOKEN` opcional

## Observações
- O endpoint `/api/admin/realtime` usa polling curto robusto em vez de SSE para evitar problemas de autenticação do EventSource com header customizado.
- A landing mantém os assets locais originais e recebeu um tracker centralizado em `js/tracker.js`.
- O link de checkout recebeu `rel="noopener noreferrer"`.
