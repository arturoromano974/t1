# Vercel admin project

Projeto pronto para upload manual na Vercel com:

- landing pública em `/`
- painel administrativo em `/admin`
- funções serverless em `/api/*`
- persistência via `KV_REST_API_URL` + `KV_REST_API_TOKEN` quando disponíveis
- fallback em memória local para desenvolvimento

## Variáveis de ambiente

- `ADMIN_PASSWORD` obrigatória para liberar o `/admin`
- `KV_REST_API_URL` opcional
- `KV_REST_API_TOKEN` opcional
- `KV_REST_API_READ_ONLY_TOKEN` opcional

## Deploy na Vercel

1. Faça upload da pasta inteira.
2. Configure `ADMIN_PASSWORD`.
3. Se quiser persistência compartilhada entre invocações, configure também as variáveis de KV REST.
4. Publique o projeto.

## Rodar localmente

```bash
npm run dev
```

Servidor local:

- landing: `http://localhost:3000/`
- admin: `http://localhost:3000/admin`
