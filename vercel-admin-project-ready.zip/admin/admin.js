(() => {
  let adminKey = '';
  let pollingTimer = null;

  const els = {
    loginForm: document.getElementById('login-form'),
    password: document.getElementById('admin-password'),
    loginMessage: document.getElementById('login-message'),
    buttonLogout: document.getElementById('button-logout'),
    buttonRefresh: document.getElementById('button-refresh'),
    statusRealtime: document.getElementById('status-realtime'),
    statusStorage: document.getElementById('status-storage'),
    statusLastEvent: document.getElementById('status-last-event'),
    metricPageviews: document.getElementById('metric-pageviews'),
    metricSessions: document.getElementById('metric-sessions'),
    metricCta: document.getElementById('metric-cta'),
    metricScroll: document.getElementById('metric-scroll'),
    listSources: document.getElementById('list-sources'),
    listDevices: document.getElementById('list-devices'),
    listBrowsers: document.getElementById('list-browsers'),
    listReferrers: document.getElementById('list-referrers'),
    listPaths: document.getElementById('list-paths'),
    listEventCounts: document.getElementById('list-event-counts'),
    funnel: document.getElementById('funnel-container'),
    eventsTable: document.getElementById('events-table'),
    timeline: document.getElementById('timeline')
  };

  function setMessage(text, kind = '') {
    if (!text) {
      els.loginMessage.className = 'message hidden';
      els.loginMessage.textContent = '';
      return;
    }
    els.loginMessage.className = `message ${kind}`.trim();
    els.loginMessage.textContent = text;
  }

  function formatNumber(value) {
    return new Intl.NumberFormat('pt-BR').format(Number(value || 0));
  }

  function formatTime(value) {
    if (!value) return '--';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '--';
    return date.toLocaleString('pt-BR');
  }

  function createListMarkup(items, emptyLabel) {
    if (!items || !items.length) {
      return `<li><span>${emptyLabel}</span><span class="tag">0</span></li>`;
    }
    const max = Math.max(...items.map((item) => Number(item.count || 0)), 1);
    return items.map((item) => {
      const width = Math.max(6, Math.round((Number(item.count || 0) / max) * 100));
      return `
        <li>
          <div class="bar-row">
            <div class="bar-labels"><span>${escapeHtml(item.label)}</span><strong>${formatNumber(item.count)}</strong></div>
            <div class="bar-track"><div class="bar-fill" style="width:${width}%"></div></div>
          </div>
        </li>
      `;
    }).join('');
  }

  function createFunnelMarkup(items) {
    if (!items || !items.length) {
      return '<div class="muted">Sem dados do funil ainda.</div>';
    }
    const max = Math.max(...items.map((item) => Number(item.count || 0)), 1);
    return items.map((item) => {
      const width = Math.max(5, Math.round((Number(item.count || 0) / max) * 100));
      return `
        <div class="funnel-step">
          <div class="funnel-name">${escapeHtml(item.label)}</div>
          <div class="bar-track"><div class="bar-fill" style="width:${width}%"></div></div>
          <div class="funnel-count">${formatNumber(item.count)}</div>
          <div class="funnel-rate">${item.rateFromStart}%</div>
        </div>
      `;
    }).join('');
  }

  function createEventRows(events) {
    if (!events || !events.length) {
      return '<tr><td colspan="6" class="muted">Nenhum evento registrado.</td></tr>';
    }
    return events.map((event) => `
      <tr data-testid="row-event-${escapeAttr(event.id || event.timestamp || event.type)}">
        <td><span class="tag">${escapeHtml(event.type || '--')}</span></td>
        <td>${escapeHtml(formatTime(event.timestamp))}</td>
        <td>${escapeHtml((event.sessionId || '--').slice(0, 18))}</td>
        <td>${escapeHtml(event.path || '--')}</td>
        <td>${escapeHtml(event.utm_source || event.referrer || 'direct')}</td>
        <td>${escapeHtml(`${event.device || '--'} / ${event.browser || '--'}`)}</td>
      </tr>
    `).join('');
  }

  function createTimeline(events) {
    if (!events || !events.length) {
      return '<div class="muted">Nenhum evento recente.</div>';
    }
    return events.slice(0, 10).map((event) => `
      <article class="timeline-item" data-testid="timeline-item-${escapeAttr(event.id || event.timestamp || event.type)}">
        <div class="timeline-point"></div>
        <div class="timeline-card">
          <div class="timeline-head">
            <strong>${escapeHtml(event.type || '--')}</strong>
            <span class="muted">${escapeHtml(formatTime(event.timestamp))}</span>
          </div>
          <div class="muted">${escapeHtml(event.path || '--')} • ${escapeHtml(event.device || '--')} • ${escapeHtml(event.browser || '--')}</div>
          <div class="helper">Sessão ${escapeHtml((event.sessionId || '--').slice(0, 20))} ${event.utm_source ? `• UTM ${escapeHtml(event.utm_source)}` : ''}</div>
        </div>
      </article>
    `).join('');
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/\s+/g, '-');
  }

  function setLoggedInState(isLoggedIn) {
    els.buttonLogout.classList.toggle('hidden', !isLoggedIn);
    els.password.disabled = isLoggedIn;
  }

  async function api(path) {
    const response = await fetch(path, {
      headers: adminKey ? { 'x-admin-key': adminKey } : {}
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.error || data.warning || 'Falha na API');
      error.data = data;
      throw error;
    }
    return data;
  }

  async function login(password) {
    const response = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.error || data.warning || 'Falha no login');
      error.data = data;
      throw error;
    }
    return data;
  }

  async function refreshAll() {
    if (!adminKey) return;
    const [summaryResponse, eventsResponse, funnelResponse] = await Promise.all([
      api('/api/admin/summary'),
      api('/api/admin/events?limit=60'),
      api('/api/admin/funnel')
    ]);

    renderSummary(summaryResponse.summary, summaryResponse.storageMode);
    renderEvents(eventsResponse.events || []);
    renderFunnel(funnelResponse.funnel || []);
    els.statusRealtime.textContent = 'Atualizado';
  }

  function renderSummary(summary, storageMode) {
    if (!summary) return;
    els.statusStorage.textContent = storageMode || '--';
    els.statusLastEvent.textContent = formatTime(summary.lastEventAt);
    els.metricPageviews.textContent = formatNumber(summary.totalPageviews);
    els.metricSessions.textContent = formatNumber(summary.uniqueSessions);
    els.metricCta.textContent = formatNumber(summary.ctaClicks);
    els.metricScroll.textContent = `${summary.avgScrollDepth || 0}%`;
    els.listSources.innerHTML = createListMarkup(summary.topSources, 'Sem UTM source');
    els.listDevices.innerHTML = createListMarkup(summary.topDevices, 'Sem device');
    els.listBrowsers.innerHTML = createListMarkup(summary.topBrowsers, 'Sem browser');
    els.listReferrers.innerHTML = createListMarkup(summary.topReferrers, 'Sem referrer');
    els.listPaths.innerHTML = createListMarkup(summary.topPaths, 'Sem paths');
    els.listEventCounts.innerHTML = createListMarkup(
      Object.entries(summary.eventCounts || {}).map(([label, count]) => ({ label, count })),
      'Sem eventos'
    );
  }

  function renderEvents(events) {
    els.eventsTable.innerHTML = createEventRows(events);
    els.timeline.innerHTML = createTimeline(events);
  }

  function renderFunnel(funnel) {
    els.funnel.innerHTML = createFunnelMarkup(funnel);
  }

  async function pollRealtime() {
    if (!adminKey) return;
    const data = await api('/api/admin/realtime');
    renderSummary(data.summary, data.storageMode);
    renderEvents(data.recentEvents || []);
    renderFunnel(data.funnel || []);
    els.statusRealtime.textContent = 'Polling ativo';
  }

  function attachRealtime() {
    if (!adminKey) return;
    if (pollingTimer) window.clearInterval(pollingTimer);
    pollRealtime().catch((error) => {
      console.error(error);
      els.statusRealtime.textContent = 'Falha no polling';
    });
    pollingTimer = window.setInterval(() => {
      pollRealtime().catch((error) => {
        console.error(error);
        els.statusRealtime.textContent = 'Falha no polling';
      });
    }, 5000);
  }

  els.loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const password = els.password.value.trim();
    if (!password) {
      setMessage('Digite a senha do admin.', 'error');
      return;
    }

    try {
      const data = await login(password);
      adminKey = password;
      setLoggedInState(true);
      setMessage(`Login liberado. Storage atual: ${data.storageMode}.`, 'success');
      await refreshAll();
      attachRealtime();
    } catch (error) {
      const message = error.data?.warning || error.data?.error || error.message;
      setMessage(message, 'error');
    }
  });

  els.buttonLogout.addEventListener('click', () => {
    adminKey = '';
    if (pollingTimer) window.clearInterval(pollingTimer);
    pollingTimer = null;
    setLoggedInState(false);
    els.password.disabled = false;
    els.password.value = '';
    els.statusRealtime.textContent = 'Sessão encerrada';
    setMessage('Login removido do navegador.', 'success');
  });

  els.buttonRefresh.addEventListener('click', async () => {
    try {
      await refreshAll();
    } catch (error) {
      setMessage(error.data?.error || error.message, 'error');
    }
  });

  setLoggedInState(false);
})();
