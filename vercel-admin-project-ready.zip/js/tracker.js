(() => {
  const TRACK_ENDPOINT = '/api/track';
  const MILESTONES = [25, 50, 75, 100];
  const sentMilestones = new Set();
  const sessionId = typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : `sess-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  let heartbeatCount = 0;

  function readParams() {
    const params = new URLSearchParams(window.location.search);
    return {
      utm_source: params.get('utm_source') || '',
      utm_medium: params.get('utm_medium') || '',
      utm_campaign: params.get('utm_campaign') || '',
      utm_content: params.get('utm_content') || '',
      utm_term: params.get('utm_term') || '',
      fbclid: params.get('fbclid') || ''
    };
  }

  function buildPayload(type, extra = {}) {
    return {
      type,
      eventType: type,
      sessionId,
      path: window.location.pathname,
      href: window.location.href,
      title: document.title,
      referrer: document.referrer || '',
      userAgent: navigator.userAgent,
      language: navigator.language || '',
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || '',
      screen: `${window.screen.width}x${window.screen.height}`,
      viewport: `${window.innerWidth}x${window.innerHeight}`,
      ...readParams(),
      ...extra,
      timestamp: new Date().toISOString()
    };
  }

  function postEvent(payload) {
    const body = JSON.stringify(payload);
    try {
      if (navigator.sendBeacon) {
        const blob = new Blob([body], { type: 'application/json' });
        const accepted = navigator.sendBeacon(TRACK_ENDPOINT, blob);
        if (accepted) return;
      }
    } catch (error) {
      // fallback to fetch below
    }

    fetch(TRACK_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      keepalive: true
    }).catch(() => {});
  }

  function track(type, extra = {}) {
    postEvent(buildPayload(type, extra));
  }

  function handleScroll() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop || 0;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrollPercent = docHeight <= 0 ? 100 : Math.min(100, Math.round((scrollTop / docHeight) * 100));

    MILESTONES.forEach((milestone) => {
      if (scrollPercent >= milestone && !sentMilestones.has(milestone)) {
        sentMilestones.add(milestone);
        track(`scroll_${milestone}`, { scrollPercent: milestone });
      }
    });
  }

  function attachClicks() {
    document.querySelectorAll('a[href="#price"], .elementor-button[href="#price"]').forEach((node, index) => {
      node.dataset.track = node.dataset.track || 'cta';
      node.dataset.trackLabel = node.dataset.trackLabel || `cta-${index + 1}`;
      node.addEventListener('click', () => {
        track('cta_click', {
          ctaLabel: node.textContent.trim(),
          sourceContext: node.dataset.trackLabel,
          scrollPercent: sentMilestones.has(100) ? 100 : Math.max(...Array.from(sentMilestones.values(), (value) => Number(value) || 0), 0)
        });
      });
    });

    document.querySelectorAll('a[href*="checkout"], a[href*="lastlink.com"]').forEach((node) => {
      node.dataset.track = 'checkout';
      node.addEventListener('click', () => {
        track('checkout_click', {
          ctaLabel: node.textContent.trim(),
          checkoutUrl: node.href
        });
      });
    });
  }

  function startHeartbeat() {
    window.setInterval(() => {
      if (document.hidden) return;
      heartbeatCount += 1;
      if (heartbeatCount > 8) return;
      track('heartbeat', { heartbeatCount });
    }, 15000);
  }

  window.addEventListener('DOMContentLoaded', () => {
    track('session_start');
    track('page_view');
    attachClicks();
    handleScroll();
    startHeartbeat();
    window.addEventListener('scroll', handleScroll, { passive: true });
  });
})();
