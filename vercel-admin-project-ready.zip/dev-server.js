const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const root = __dirname;
const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function augmentResponse(res) {
  res.status = function status(code) {
    res.statusCode = code;
    return res;
  };
  res.json = function json(payload) {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.end(JSON.stringify(payload));
  };
  res.send = function send(payload) {
    if (typeof payload === 'object' && !Buffer.isBuffer(payload)) {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.end(JSON.stringify(payload));
      return;
    }
    res.end(payload);
  };
  return res;
}

function safeJoin(base, target) {
  const targetPath = path.normalize(path.join(base, target));
  if (!targetPath.startsWith(base)) return null;
  return targetPath;
}

function serveFile(res, filePath) {
  const extension = path.extname(filePath).toLowerCase();
  const contentType = mimeTypes[extension] || 'application/octet-stream';
  const stream = fs.createReadStream(filePath);
  res.statusCode = 200;
  res.setHeader('Content-Type', contentType);
  stream.pipe(res);
  stream.on('error', () => {
    res.statusCode = 500;
    res.end('File read error');
  });
}

const server = http.createServer(async (req, res) => {
  augmentResponse(res);
  const parsedUrl = url.parse(req.url, true);
  req.query = parsedUrl.query || {};

  if (parsedUrl.pathname.startsWith('/api/')) {
    const handlerFile = safeJoin(root, `${parsedUrl.pathname}.js`);
    if (!handlerFile || !fs.existsSync(handlerFile)) {
      res.statusCode = 404;
      return res.end(JSON.stringify({ ok: false, error: 'API route not found.' }));
    }
    delete require.cache[require.resolve(handlerFile)];
    const handler = require(handlerFile);
    return handler(req, res);
  }

  let requestedPath = parsedUrl.pathname;
  if (requestedPath === '/') requestedPath = '/index.html';
  if (requestedPath === '/admin') requestedPath = '/admin/index.html';
  if (requestedPath.endsWith('/')) requestedPath = `${requestedPath}index.html`;

  const filePath = safeJoin(root, requestedPath);
  if (filePath && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return serveFile(res, filePath);
  }

  res.statusCode = 404;
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.end('Not found');
});

const port = Number(process.env.PORT || 3000);
server.listen(port, () => {
  console.log(`Local dev server running at http://localhost:${port}`);
});
