const { applyCors, readJsonBody, sendJson, getAdminPassword } = require('../../lib/http');
const { getStorageMode } = require('../../lib/storage');

module.exports = async (req, res) => {
  if (applyCors(req, res)) return;

  if (req.method !== 'POST') {
    return sendJson(res, 405, { ok: false, error: 'Method not allowed.' });
  }

  const adminPassword = getAdminPassword();
  if (!adminPassword) {
    return sendJson(res, 503, {
      ok: false,
      configured: false,
      warning: 'ADMIN_PASSWORD não está configurada no servidor.',
      storageMode: getStorageMode()
    });
  }

  const payload = await readJsonBody(req);
  const password = String(payload.password || '');
  if (password !== adminPassword) {
    return sendJson(res, 401, {
      ok: false,
      configured: true,
      error: 'Senha inválida.'
    });
  }

  return sendJson(res, 200, {
    ok: true,
    configured: true,
    storageMode: getStorageMode()
  });
};
