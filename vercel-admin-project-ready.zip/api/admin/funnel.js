const { getFunnel, getStorageMode } = require('../../lib/storage');
const { applyCors, authenticateAdmin, sendJson } = require('../../lib/http');

module.exports = async (req, res) => {
  if (applyCors(req, res)) return;
  if (req.method !== 'GET') {
    return sendJson(res, 405, { ok: false, error: 'Method not allowed.' });
  }
  if (!authenticateAdmin(req, res)) return;

  const funnel = await getFunnel();
  return sendJson(res, 200, {
    ok: true,
    storageMode: getStorageMode(),
    funnel
  });
};
