const { getRecentEvents, getStorageMode } = require('../../lib/storage');
const { applyCors, authenticateAdmin, sendJson } = require('../../lib/http');

module.exports = async (req, res) => {
  if (applyCors(req, res)) return;
  if (req.method !== 'GET') {
    return sendJson(res, 405, { ok: false, error: 'Method not allowed.' });
  }
  if (!authenticateAdmin(req, res)) return;

  const limit = Math.min(200, Math.max(1, Number(req.query?.limit || 50)));
  const events = await getRecentEvents(limit);
  return sendJson(res, 200, {
    ok: true,
    storageMode: getStorageMode(),
    events,
    count: events.length
  });
};
