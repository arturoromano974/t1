const { recordEvent, getStorageMode } = require('../lib/storage');
const { applyCors, readJsonBody, sendJson } = require('../lib/http');

module.exports = async (req, res) => {
  if (applyCors(req, res)) return;

  if (req.method !== 'POST') {
    return sendJson(res, 405, { ok: false, error: 'Method not allowed.' });
  }

  const payload = await readJsonBody(req);
  const { event, mode } = await recordEvent(payload, req);

  return sendJson(res, 200, {
    ok: true,
    mode: mode || getStorageMode(),
    acceptedEvent: event.type,
    sessionId: event.sessionId,
    timestamp: event.timestamp
  });
};
